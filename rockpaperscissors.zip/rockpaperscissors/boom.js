let userscore = 0;
let compscore = 0;

const choices = document.querySelectorAll(".choice");
const msg = document.querySelector("#msg");
const user = document.querySelector("#user-score");
const comp = document.querySelector("#comp-score");

// computerchoice function
const compchoice = () => {
    const option = ["rock", "paper", "scissors"];
    const randindex = Math.floor(Math.random() * 3);
    return option[randindex];
}
// draw function
const drawgame = () => {
    //console.log("Game draw");
    msg.innerText = "Game Drawn! Play Again";
    msg.style.backgroundColor = "goldenrod";
}
// Winning function
const showWinner = (userwin, userChoice, compChoice) => {
    if (userwin) {
        userscore++;
        user.innerText = userscore;
        msg.innerText = `You Win! Your ${userChoice} beats ${compChoice}`;
        msg.style.backgroundColor = "green";
    }
    else {
        compscore++;
        comp.innerText = compscore;
        msg.innerText = `You Loose! ${compChoice} beats your ${userChoice}`;
        msg.style.backgroundColor = "red";

    }
}
// logic behind gameplay
const playgame = (userchoice) => {
    //your choice
    console.log("Userchoice = ", userchoice);
    //computer choice
    const Compchoice = compchoice();
    console.log("Computerchoice = ", Compchoice);
    //drawcase
    if (userchoice == Compchoice) {
        drawgame();
    }
    //case1
    else if (userchoice == "rock") {
        let userwin = true;
        if (Compchoice == "paper") {
            userwin = false;
        }
        else if (Compchoice == "scissors") {
            userwin = true;
        }
        showWinner(userwin, userchoice, Compchoice);
    }
    //case2
    else if (userchoice == "paper") {
        let userwin = true;
        if (Compchoice == "scissors") {
            userwin = false;
        }
        else if (Compchoice == "rock") {
            userwin = true;
        }
        showWinner(userwin, userchoice, Compchoice);
    }
    //case3
    else if (userchoice == "scissors") {
        let userwin = true;
        if (Compchoice == "rock") {
            userwin = false;
        }
        else if (Compchoice == "paper") {
            userwin = true;
        }
        showWinner(userwin, userchoice, Compchoice);
    }
}
// choosing rock,paper,etc, on the basis of id
choices.forEach((choice) => {
    choice.addEventListener("click", () => {
        const userchoice = choice.getAttribute("id");
        playgame(userchoice);
    });
})
